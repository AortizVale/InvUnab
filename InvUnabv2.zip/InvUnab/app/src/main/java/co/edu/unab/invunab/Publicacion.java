package co.edu.unab.invunab;

public class Publicacion {
    public int identificador;
    public String autor;
    public String fecha;
    public String urlImagenAutor;
    public String fechaPublicacion;
    public String titulo;
    public String descripcion;
    public String urlArchivo;

    public Publicacion(String autor, String fecha, String urlImagenAutor, String fechaPublicacion, String titulo, String descripcion, String urlArchivo) {
        this.identificador=0;
        this.autor = autor;
        this.fecha = fecha;
        this.urlImagenAutor = urlImagenAutor;
        this.fechaPublicacion = fechaPublicacion;
        this.titulo = titulo;
        this.descripcion = descripcion;
        this.urlArchivo = urlArchivo;
    }

    public int getIdentificador() {
        return identificador;
    }

    public void setIdentificador(int identificador) {
        this.identificador = identificador;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getFecha() {
        return fecha;
    }

    public void setFecha(String fecha) {
        this.fecha = fecha;
    }

    public String getUrlImagenAutor() {
        return urlImagenAutor;
    }

    public void setUrlImagenAutor(String urlImagenAutor) {
        this.urlImagenAutor = urlImagenAutor;
    }

    public String getFechaPublicacion() {
        return fechaPublicacion;
    }

    public void setFechaPublicacion(String fechaPublicacion) {
        this.fechaPublicacion = fechaPublicacion;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getUrlArchivo() {
        return urlArchivo;
    }

    public void setUrlArchivo(String urlArchivo) {
        this.urlArchivo = urlArchivo;
    }
}