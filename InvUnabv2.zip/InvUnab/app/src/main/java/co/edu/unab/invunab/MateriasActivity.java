package co.edu.unab.invunab;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MateriasActivity extends AppCompatActivity {

    ArrayList<Materia> listadoMaterias;
    RecyclerView rvMaterias;

    private AdaptadorMaterias adaptador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_materias);
        cargarFakeListaMaterias();

        AdaptadorMaterias adaptador = new AdaptadorMaterias(listadoMaterias);
        adaptador.setOnItemClickListener(new AdaptadorMaterias.OnItemClickListener() {
            @Override
            public void onItemClick(Materia materia, int posicion) {
                //Toast.makeText(MateriasActivity.this, "click "+materia.getNombre(), Toast.LENGTH_SHORT).show();
                Intent siguiente = new Intent(MateriasActivity.this,PublicacionesActivity.class);
                //siguiente.putExtra("idMateria",materia.getIdentificador());
                startActivity(siguiente);
            }
        });

        rvMaterias=findViewById(R.id.rv_materias);
        rvMaterias.setLayoutManager(new LinearLayoutManager(this));
        rvMaterias.setAdapter(adaptador);
    }

    private void cargarFakeListaMaterias(){
        listadoMaterias=new ArrayList<>();
        Materia materiaEcuaciones = new Materia(1,"Ecuaciones diferenciales","https://cdn-icons-png.flaticon.com/512/1603/1603002.png");
        Materia materiaElectro = new Materia(2, "Electromagnetismo","https://i.kym-cdn.com/photos/images/original/001/547/548/b12.png");
        Materia materiaDM = new Materia (3, "Desarrollo multimedia","https://cdn-icons-png.flaticon.com/512/5260/5260498.png");
        listadoMaterias.add(materiaEcuaciones);
        listadoMaterias.add(materiaElectro);
        listadoMaterias.add(materiaDM);
    }
}