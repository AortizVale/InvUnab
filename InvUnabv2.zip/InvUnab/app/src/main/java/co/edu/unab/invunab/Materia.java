package co.edu.unab.invunab;

import java.io.Serializable;

public class Materia {

    private int identificador;
    private String nombre;
    private String urlImagen;

    //Constructor



    public Materia(int identificador, String nombre, String urlImagen) {
        this.identificador=identificador;
        this.nombre = nombre;
        this.urlImagen = urlImagen;
    }

    //Getters y setters


    public int getIdentificador() {
        return identificador;
    }

    public void setIdentificador(int identificador) {
        this.identificador = identificador;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getUrlImagen() {
        return urlImagen;
    }

    public void setUrlImagen(String urlImagen) {
        this.urlImagen = urlImagen;
    }
}
