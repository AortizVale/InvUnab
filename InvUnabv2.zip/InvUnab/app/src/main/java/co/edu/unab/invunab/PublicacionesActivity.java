package co.edu.unab.invunab;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class PublicacionesActivity extends AppCompatActivity {

    ArrayList<Publicacion> listadoPublicaciones;
    RecyclerView rvPublicacion;

    private AdaptadorPublicaciones adaptador;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publicaciones);
        cargarFakeListaPublicaciones();

        AdaptadorPublicaciones adaptador = new AdaptadorPublicaciones(listadoPublicaciones);
        adaptador.setOnItemClickListener(new AdaptadorPublicaciones.OnItemClickListener() {
            @Override
            public void onItemClick(Publicacion publicacion, int posicion) {
                Toast.makeText(PublicacionesActivity.this, "click "+publicacion.getTitulo(), Toast.LENGTH_SHORT).show();
                //Intent siguiente = new Intent(PublicacionesActivity.this,PublicacionesActivity.class);
                //startActivity(siguiente);
            }
        });

        rvPublicacion=findViewById(R.id.rv_publicaciones);
        rvPublicacion.setLayoutManager(new LinearLayoutManager(this));
        rvPublicacion.setAdapter(adaptador);
    }
    private void cargarFakeListaPublicaciones(){
        listadoPublicaciones=new ArrayList<>();
        Publicacion publicacionEcuaciones = new Publicacion("","","","","","","");
        Publicacion publicacionElectro1 = new Publicacion("","","","","","","");
        Publicacion publicacionElectro2 = new Publicacion("","","","","","","");
        listadoPublicaciones.add(publicacionEcuaciones);
        listadoPublicaciones.add(publicacionElectro1);
        listadoPublicaciones.add(publicacionElectro2);
    }
}