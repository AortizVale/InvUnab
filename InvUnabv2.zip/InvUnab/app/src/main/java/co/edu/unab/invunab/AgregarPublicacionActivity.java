package co.edu.unab.invunab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class AgregarPublicacionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agregar_publicacion);
    }
}